@if (!empty($data))
    <div id="{{ $context }}-sortables" class="meta-box-sortables">
        {!! $data !!}
    </div>
@endif
